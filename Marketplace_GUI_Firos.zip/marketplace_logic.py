# marketplace_logic.py – logika handlu
class TradeOffer:
    def __init__(self, from_player, to_player, item_given, item_wanted):
        self.from_player = from_player
        self.to_player = to_player
        self.item_given = item_given
        self.item_wanted = item_wanted

    def __str__(self):
        return f"{self.from_player} oferuje {self.item_given} za {self.item_wanted} gracza {self.to_player}"

class Marketplace:
    def __init__(self):
        self.offers = []

    def create_offer(self, from_player, to_player, item_given, item_wanted):
        offer = TradeOffer(from_player, to_player, item_given, item_wanted)
        self.offers.append(offer)

    def get_all_offers(self):
        return self.offers
