# marketplace_main.py – główny interfejs GUI do handlu
import tkinter as tk
from marketplace_logic import Marketplace, TradeOffer

class MarketplaceGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Marketplace Firos")
        self.marketplace = Marketplace()
        self.label = tk.Label(master, text="Witaj w Markecie Firos", font=("Arial", 14))
        self.label.pack(pady=10)
        self.load_ui()

    def load_ui(self):
        tk.Button(self.master, text="Zobacz oferty", command=self.view_offers).pack(pady=5)
        tk.Button(self.master, text="Wystaw przedmiot", command=self.create_offer).pack(pady=5)

    def view_offers(self):
        offers = self.marketplace.get_all_offers()
        window = tk.Toplevel(self.master)
        window.title("Dostępne oferty")
        for offer in offers:
            tk.Label(window, text=str(offer)).pack()

    def create_offer(self):
        window = tk.Toplevel(self.master)
        window.title("Wystaw ofertę")
        tk.Label(window, text="Gracz docelowy:").pack()
        entry_target = tk.Entry(window)
        entry_target.pack()
        tk.Label(window, text="Co dajesz:").pack()
        entry_give = tk.Entry(window)
        entry_give.pack()
        tk.Label(window, text="Czego oczekujesz:").pack()
        entry_receive = tk.Entry(window)
        entry_receive.pack()
        def submit():
            self.marketplace.create_offer("graczX", entry_target.get(), entry_give.get(), entry_receive.get())
            window.destroy()
        tk.Button(window, text="Zatwierdź", command=submit).pack()

if __name__ == "__main__":
    root = tk.Tk()
    gui = MarketplaceGUI(root)
    root.mainloop()
