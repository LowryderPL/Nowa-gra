RUNES = [
    {"name": "Runa Ognia", "effect": "+10% obrażeń od ognia"},
    {"name": "Runa Mrozu", "effect": "Spowolnienie wroga"},
    {"name": "Runa Krwi", "effect": "+5% lifesteal"},
    {"name": "Runa Cienia", "effect": "+3% uniku"},
    {"name": "Runa Światła", "effect": "Odbicie 10% dmg"},
]
